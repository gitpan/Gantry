# NEVER EDIT this file.  It was generated and will be overwritten without
# notice upon regeneration of this application.  You have been warned.
package Billing::GEN::Invoice;

use strict;
use warnings;

use base 'Billing';
use JSON;
use Gantry::Utils::TablePerms;

use Billing::Model::invoice qw(
    $INVOICE
);
use Gantry::Plugins::Calendar qw(
    do_calendar_month
    calendar_month_js
);



#-----------------------------------------------------------------
# $self->do_main(  )
#-----------------------------------------------------------------
sub do_main {
    my ( $self ) = @_;

    $self->stash->view->template( 'results.tt' );
    $self->stash->view->title( 'Invoices' );

    my $real_location = $self->location() || '';
    if ( $real_location ) {
        $real_location =~ s{/+$}{};
        $real_location .= '/';
    }

    my @header_options = (
        {
            text => 'Add',
            link => $real_location . "add",
            type => 'create',
        },
    );

    my $retval = {
        headings       => [
            'Number',
            'Customer',
            'Status',
        ],
    };

    my %param = $self->get_param_hash;

    my $search = {};
    if ( $param{ search } ) {
        my $form = $self->form();

        my @searches;
        foreach my $field ( @{ $form->{ fields } } ) {
            if ( $field->{ searchable } ) {
                push( @searches,
                    ( $field->{ name } => { 'like', "%$param{ search }%"  } )
                );
            }
        }

        $search = {
            -or => \@searches
        } if scalar( @searches ) > 0;
    }

    my @row_options = (
        {
            text => 'Tasks',
            link => "/lineitem/main",
            type => 'retrieve',
        },
        {
            text => 'PDF',
            type => 'retrieve',
        },
        {
            text => 'Edit',
            type => 'update',
        },
        {
            text => 'Delete',
            type => 'delete',
        },
    );

    my $perm_obj = Gantry::Utils::TablePerms->new(
        {
            site           => $self,
            real_location  => $real_location,
            header_options => \@header_options,
            row_options    => \@row_options,
        }
    );

    $retval->{ header_options } = $perm_obj->real_header_options;

    my $limit_to_user_id = $perm_obj->limit_to_user_id;
    $search->{ user_id } = $limit_to_user_id if ( $limit_to_user_id );

    my $schema = $self->get_schema();
    my @rows   = $INVOICE->get_listing(
        {
            schema   => $schema,
            where    => $search,
        }
    );

    ROW:
    foreach my $row ( @rows ) {
        last ROW if $perm_obj->hide_all_data;

        my $id = $row->id;
        my $customer = ( $row->customer )
                ? $row->customer->foreign_display()
                : '';
        my $status = ( $row->status )
                ? $row->status->foreign_display()
                : '';

        push(
            @{ $retval->{rows} }, {
                orm_row => $row,
                data => [
                    $row->number,
                    $customer,
                    $status,
                ],
                options => $perm_obj->real_row_options( $row ),
            }
        );
    }

    if ( $param{ json } ) {
        $self->template_disable( 1 );

        my $obj = {
            headings        => $retval->{ headings },
            header_options  => $retval->{ header_options },
            rows            => $retval->{ rows },
        };

        my $json = objToJson( $obj, { skipinvalid => 1 } );
        return( $json );
    }

    $self->stash->view->data( $retval );
} # END do_main

#-----------------------------------------------------------------
# $self->form( $row )
#-----------------------------------------------------------------
sub form {
    my ( $self, $row ) = @_;

    my $selections = $INVOICE->get_form_selections(
            { schema => $self->get_schema() }
    );

    return {
        name       => 'invoice',
        row        => $row,
        legend => $self->path_info =~ /edit/i ? 'Edit' : 'Add',
        javascript => $self->calendar_month_js( 'invoice' ),
        fields     => [
            {
                name => 'number',
                label => 'Number',
                type => 'text',
                is => 'varchar',
            },
            {
                options => $selections->{status},
                name => 'status',
                label => 'Status',
                type => 'select',
                is => 'int4',
            },
            {
                date_select_text => 'Popup Calendar',
                name => 'sent',
                optional => 1,
                label => 'Sent On',
                type => 'text',
                is => 'date',
            },
            {
                date_select_text => 'Popup Calendar',
                name => 'paid',
                optional => 1,
                label => 'Paid On',
                type => 'text',
                is => 'date',
            },
            {
                options => $selections->{my_company},
                name => 'my_company',
                label => 'My Company',
                type => 'select',
                is => 'int4',
            },
            {
                options => $selections->{customer},
                name => 'customer',
                label => 'Customer',
                type => 'select',
                is => 'int4',
            },
            {
                name => 'notes',
                optional => 1,
                label => 'Notes to Customer',
                type => 'textarea',
                is => 'text',
                rows => 4,
                cols => 50,
            },
            {
                name => 'description',
                optional => 1,
                label => 'Notes to Self',
                type => 'textarea',
                is => 'text',
                rows => 4,
                cols => 50,
            },
        ],
    };
} # END form

1;

=head1 NAME

Billing::GEN::Invoice - generated support module for Billing::Invoice

=head1 SYNOPSIS

In Billing::Invoice:

    use base 'Billing::GEN::Invoice';

=head1 DESCRIPTION

This module was generated by bigtop and IS subject to regeneration.
Use it in Billing::Invoice to provide the methods below.
Feel free to override them.

=head1 METHODS

=over 4

=item do_main

=item form


=back

=head1 AUTHOR

Generated by bigtop and subject to regeneration.

=cut

